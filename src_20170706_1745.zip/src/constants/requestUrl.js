export const REQUEST_URL = 'https://www.reddit.com';
