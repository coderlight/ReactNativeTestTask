export const storageKeys = {
  token: 'token',
  username: 'username',
};
