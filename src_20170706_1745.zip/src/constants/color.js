export const color = {
  primary: '#9C27B0',
  primaryLight: '#CE93D8',
  red: 'red',
  yellow: 'yellow',
  gray: '#aaa',
  black: '#000',
  grayLight: '#eee',
  white: '#fff',
  transparent: 'transparent',
  background: '#ddd',
};
